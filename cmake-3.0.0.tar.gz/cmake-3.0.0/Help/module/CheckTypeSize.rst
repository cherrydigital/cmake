.. cmake-module:: ../../Modules/CheckTypeSize.cmake
