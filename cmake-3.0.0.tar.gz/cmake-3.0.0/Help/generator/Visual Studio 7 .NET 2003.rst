Visual Studio 7 .NET 2003
-------------------------

Generates Visual Studio .NET 2003 project files.
