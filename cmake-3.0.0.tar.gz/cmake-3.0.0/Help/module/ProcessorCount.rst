.. cmake-module:: ../../Modules/ProcessorCount.cmake
