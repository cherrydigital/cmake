.. cmake-module:: ../../Modules/FindosgFX.cmake
