.. cmake-module:: ../../Modules/CMakeGraphVizOptions.cmake
