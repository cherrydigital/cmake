.. cmake-module:: ../../Modules/FindVTK.cmake
